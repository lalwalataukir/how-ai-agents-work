"""Security checks for the codebase assistant. The code it reads is untrusted: a comment can say
anything, and the model's tool calls can ask for any path. These checks decide what's allowed."""
import re
from pathlib import Path

MAX_QUESTION = 2000  # characters
TOOL_LIMITS = {"search_code": 6, "read_lines": 8, "list_dir": 4}  # calls per question
SECRET_NAMES = re.compile(r"^\.env|\.(pem|key|p12|pfx)$|^id_(rsa|ed25519|ecdsa)|secret|credential", re.IGNORECASE)
INSTRUCTION_LIKE = re.compile(
    r"ignore (all |any |the )?(previous |prior |above |earlier |your )+(instructions|rules)"
    r"|disregard [^.]{0,40}instructions|you are now|new instructions|system prompt"
    r"|note (for|to) (ai|llm|language model)", re.IGNORECASE)


def safe_path(root, path, folder=False):
    """The real path of a file (or folder) inside root, or ValueError. Refuses ../ and absolute paths,
    links that lead outside, hidden files and folders (.git, .env), and files named like secrets."""
    # TODO milestone 4: resolve the path and refuse anything outside root, hidden, or named like a
    # secret. Until then, any path works, even ../../.ssh/id_rsa:
    return Path(root) / path


def untrusted(source, text):
    """Spotlighting, as in E10: wrap tool output in tags the system prompt says hold data. A closing
    tag inside the text is broken up, and text that looks like instructions gets a warning."""
    # TODO milestone 4: wrap text in <untrusted source="..."> tags, with a warning when it looks like
    # instructions. Until then, tool output goes to Claude as it is:
    return text


def limit_reached(counts, name):
    """True once a tool has been called more times this question than TOOL_LIMITS allows."""
    # TODO milestone 4: compare counts[name] with TOOL_LIMITS. Until then, no limits:
    return False


def clean_question(text):
    """Drop invisible control characters, tidy spaces, and refuse empty or huge questions."""
    # TODO milestone 4: as E10's clean_question. Until then, questions go through as they are:
    return text
