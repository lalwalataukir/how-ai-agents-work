"""Data-analysis agent: ask questions about the shop's sales in plain English. Claude writes SQL,
the code runs it read-only and safely, and every answer shows the queries behind it.

Run it with:
    uv run make_data.py                                    # once: makes shop.db
    uv run analyst.py                                      # ask questions, with follow-ups
    uv run analyst.py "What was revenue in March 2025?"    # one question
    uv run analyst.py --schema                             # what Claude knows about the data
"""
import json
import re
import sqlite3
import sys
import time
from dataclasses import dataclass, field
from pathlib import Path

import anthropic
import matplotlib
from dotenv import load_dotenv
from pydantic import BaseModel

matplotlib.use("Agg")  # draw charts to files, without opening windows
import matplotlib.pyplot as plt  # noqa: E402

load_dotenv()

MODEL = "claude-haiku-5-5"
PRICE_IN, PRICE_OUT = 0.10, 0.50  # dollars per million tokens, for this model
HERE = Path(__file__).parent
DB = HERE / "shop.db"
CHARTS = HERE / "charts"
MAX_ROWS = 200  # the most rows one query sends back to Claude
MAX_SECONDS = 2  # the longest one query may run
MAX_CALLS = 8  # stop condition: most model calls for one question
MAX_TURNS = 6  # follow-ups remember this many earlier questions and answers

SYSTEM = """You are a data analyst for a small online shop. Answer questions about its sales
database by running SQL with the run_sql tool. The database is SQLite.

Rules:
- Get every number from a query. Never guess, and don't add up rows yourself: use SUM, COUNT and AVG.
- Money is stored in cents. Divide by 100.0 for dollars.
- Only orders with status 'completed' count as sales, unless the question says otherwise.
- Use make_chart when the user asks for a chart, or when a trend over time is the answer.
- If the data can't answer the question, say so.

Answer in one or two sentences with the key numbers, and put the main number in value.

<schema>
{schema}
</schema>"""

TOOLS = [
    {
        "name": "run_sql",
        "description": "Run one read-only SQLite SELECT query on the shop database. Returns the columns and "
                       "up to 200 rows as JSON. Errors come back as text: fix the query and try again.",
        "input_schema": {
            "type": "object",
            "properties": {"sql": {"type": "string", "description": "One SELECT statement"}},
            "required": ["sql"],
            "additionalProperties": False,
        },
        "strict": True,
    },
    {
        "name": "make_chart",
        "description": "Draw a chart from a query with exactly two columns: labels, then numbers. Saves a PNG "
                       "and returns its path. Use bar for categories, line for time.",
        "input_schema": {
            "type": "object",
            "properties": {
                "title": {"type": "string", "description": "A short chart title"},
                "kind": {"type": "string", "enum": ["bar", "line"]},
                "sql": {"type": "string", "description": "One SELECT with two columns: labels, then numbers"},
            },
            "required": ["title", "kind", "sql"],
            "additionalProperties": False,
        },
        "strict": True,
    },
]

client = anthropic.Anthropic()


# ---------- Milestone 1: know the data ----------

def describe_schema(db=DB):
    """Each table with its row count and columns. Text columns with a few distinct values list them,
    so Claude knows to write status = 'completed', not 'complete'."""
    # TODO milestone 1: for each table, a line like "orders (2000 rows)", then one line per column,
    # such as "  status TEXT: cancelled, completed, refunded". List values only when there are 8 or fewer.
    raise NotImplementedError("milestone 1: describe_schema")


# ---------- Milestone 2: a safe SQL tool ----------

ALLOWED = {sqlite3.SQLITE_SELECT, sqlite3.SQLITE_READ, sqlite3.SQLITE_FUNCTION, sqlite3.SQLITE_RECURSIVE}


def only_reads(action, *details):
    """SQLite asks this before each step of a query. Anything but reading is refused."""
    return sqlite3.SQLITE_OK if action in ALLOWED else sqlite3.SQLITE_DENY


def run_sql(db, sql, max_rows=MAX_ROWS, seconds=MAX_SECONDS):
    """Run one query, read-only. Returns {"columns", "rows", "truncated"}.
    Raises ValueError, with a message Claude can act on, for anything that isn't allowed or fails."""
    # TODO milestone 2: open db read-only (mode=ro), refuse anything but reading with only_reads,
    # stop queries after `seconds`, and return at most max_rows rows. Raise ValueError for every problem.
    raise NotImplementedError("milestone 2: run_sql")


# ---------- Milestone 3: the agent ----------

class Answer(BaseModel):
    answer: str  # one or two sentences, with the key numbers
    value: float | None  # the main number in the answer, if there is one


@dataclass
class Cost:
    calls: int = 0
    tokens_in: int = 0
    tokens_out: int = 0

    def add(self, usage):
        self.calls += 1
        self.tokens_in += usage.input_tokens
        self.tokens_out += usage.output_tokens

    def dollars(self):
        return (self.tokens_in * PRICE_IN + self.tokens_out * PRICE_OUT) / 1_000_000


@dataclass
class Result:
    answer: Answer
    queries: list = field(default_factory=list)  # every SQL query that ran, in order
    charts: list = field(default_factory=list)  # paths of the charts it saved


def run_tool(name, args, db, result):
    """Run one tool call, and keep a record of it in result. Returns the text to send back, and
    whether it failed. Errors go back to Claude so it can fix its query."""
    # TODO milestone 3: run run_sql (send make_chart to chart_tool), add each query to
    # result.queries, and turn a ValueError into an error result.
    raise NotImplementedError("milestone 3: run_tool")


def ask(question, memory=(), db=DB, cost=None):
    """Answer one question: Claude writes queries, the code runs them, until Claude answers.
    memory holds earlier questions and answers; cost adds up what every call costs."""
    # TODO milestone 3: the tool-use loop, with output_format=Answer and the schema in the system
    # prompt. Stop after MAX_CALLS calls. Return a Result.
    raise NotImplementedError("milestone 3: ask")


# ---------- Milestone 4: charts ----------

def make_chart(db, title, kind, sql):
    """Draw a two-column query (labels, numbers) as a bar or line chart. Returns the PNG's path."""
    # TODO milestone 4: run sql with run_sql, check it has two columns of labels and numbers,
    # draw it with matplotlib, save it in CHARTS as a PNG named after the title, and return the path.
    raise NotImplementedError("milestone 4: make_chart")


def chart_tool(args, db, result):
    """The make_chart tool call: returns the text to send back, and whether it failed."""
    # TODO milestone 4: call make_chart, record the query and the chart in result, send errors back.
    return "make_chart isn't built yet. Answer without a chart.", True


# ---------- Milestone 6: follow-up questions ----------

class Session:
    """A conversation: each question can refer back to earlier ones ("now split that by region")."""

    def __init__(self, db=DB):
        self.db, self.memory, self.cost = db, [], Cost()

    def ask(self, question):
        result = ask(question, self.memory, self.db, self.cost)
        self.remember(question, result)
        return result

    def remember(self, question, result):
        """Keep the question, the answer and the last queries, for at most MAX_TURNS turns."""
        # TODO milestone 6: add the question, and the answer with its last 3 queries, to self.memory.
        # Keep only the last MAX_TURNS questions and answers. Until then, nothing is remembered:
        pass


def show(session, question):
    """Answer one question in the terminal, with the queries and charts behind it."""
    try:
        result = session.ask(question)
    except anthropic.APIConnectionError:
        print("Could not reach the API. Check your internet connection and try again.")
        return
    except anthropic.APIStatusError as error:  # a bad key, no credit, overloaded: after the SDK's retries
        print(f"The API answered {error.status_code}: {error.message}")
        return
    print(result.answer.answer)
    for sql in dict.fromkeys(result.queries):  # each query once, in order
        print(f"  SQL: {sql}")
    for chart in result.charts:
        print(f"  Chart saved: {chart}")


def main(args):
    if not DB.is_file():
        sys.exit("No shop.db yet. Run: uv run make_data.py")
    if args == ["--schema"]:
        print(describe_schema(DB))
        return
    session = Session(DB)
    if args:
        show(session, " ".join(args))
    else:
        print("Ask about the shop's sales. Type quit to stop.")
        while (question := input("\nYou: ").strip()).lower() not in ("quit", "exit"):
            if question:
                show(session, question)
    print(f"[{session.cost.calls} model calls, ${session.cost.dollars():.4f}]")


if __name__ == "__main__":
    main(sys.argv[1:])
